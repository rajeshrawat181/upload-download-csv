package com.assignment.DTO;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
@AllArgsConstructor
public class ResponseDTO implements Serializable{

	public ResponseDTO() {
		
	}
	private static final long serialVersionUID = -3228266410946743949L;
    Integer no_of_rows_parsed;
    Integer no_of_rows_failed;
    String error_file_url;
}
