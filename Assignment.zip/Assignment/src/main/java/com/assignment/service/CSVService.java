package com.assignment.service;

import java.io.IOException;
import java.io.Reader;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.assignment.DTO.ResponseDTO;
import com.assignment.helper.CSVHelper;
import com.assignment.model.Role;
import com.assignment.model.User;
import com.assignment.repository.RoleRepository;
import com.assignment.repository.UserRepository;

@Service
public class CSVService {

	@Autowired
	UserRepository userRepository;
	@Autowired
	RoleRepository roleRepository;
	@Value("${file.error.csv.path}")
	private String errorFilePath;
	@Value("${error.file.url}")
	private String errorFileURL;

	public ResponseDTO save(MultipartFile file) throws IOException {

		List<User> users = CSVHelper.csvToUser(file.getInputStream());
		if (users == null || users.isEmpty()) {
			return ResponseDTO.builder().no_of_rows_parsed(0).no_of_rows_failed(0).error_file_url("").build();
		}
		Map<String, Object> records = validateUsers(users);
		@SuppressWarnings("unchecked")
		List<User> validUsers = (List<User>) records.get("valid");
		ResponseDTO response = new ResponseDTO();
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> invalidUsers = (List<Map<String, Object>>) records.get("invalid");
		if (invalidUsers == null || invalidUsers.isEmpty())
			response.setNo_of_rows_failed(0);
		else {
			response.setNo_of_rows_failed(invalidUsers.size());
			String url = writeCSVErrorFile(invalidUsers, file.getOriginalFilename());
			response.setError_file_url(url);
		}
		if (validUsers == null || validUsers.isEmpty())
			response.setNo_of_rows_parsed(0);
		else {
			response.setNo_of_rows_parsed(validUsers.size());
			userRepository.saveAll(validUsers);
		}
		return response;
	}

	private String writeCSVErrorFile(List<Map<String, Object>> invalidUsers, String fileName) throws IOException {
		CSVHelper.writeCSV(invalidUsers, fileName, errorFilePath);
		return ServletUriComponentsBuilder.fromCurrentContextPath().path(errorFileURL).path("errors_" + fileName)
				.toUriString();
	}

	private Map<String, Object> validateUsers(List<User> users) {
		Map<String, Object> final_data = new HashMap<String, Object>();
		List<User> validUsers = new ArrayList<User>();
		List<Map<String, Object>> invalidUsers = new ArrayList<Map<String, Object>>();

		for (User user : users) {
			if (isValidEmailAddress(user.getEmail())) {
				if (isUserExist(user.getEmail())) {
					invalidUsers.add(recordMessage(user, "Exist user."));
					continue;
				}
				if (checkName(user.getName())) {
					Set<Role> roles = user.getRoles();
					Role role = new Role();
					roles.forEach(r -> role.setName(r.getName()));
					if (!StringUtils.isAllBlank(role.getName())) {
						String[] split_role = role.getName().split("#");
						Set<Role> final_roles = new HashSet<Role>();
						for (String b_role : split_role) {
							Role final_role = new Role();
							final_role.setName(b_role);
							final_roles.add(final_role);
						}
						if (!isRoleExist(final_roles)) {
							invalidUsers.add(recordMessage(user, "Invalid role found."));
							continue;
						}
						user.setRoles(final_roles);
						validUsers.add(user);
					} else {
						invalidUsers.add(recordMessage(user, "Role not found."));
						continue;
					}
				} else {
					invalidUsers.add(recordMessage(user, "Name not found."));
					continue;
				}
			} else {
				invalidUsers.add(recordMessage(user, "Invalid email."));
				continue;
			}

		}
		final_data.put("valid", validUsers);
		final_data.put("invalid", invalidUsers);
		return final_data;
	}

	private Map<String, Object> recordMessage(User user, String message) {
		Map<String, Object> record = new HashMap<String, Object>();
		record.put("user", user);
		record.put("message", message);
		return record;
	}

	public boolean isRoleExist(Set<Role> roles) {
		for (Role role : roles) {
			boolean exist = roleRepository.existsByName(role.getName());
			if (!exist)
				return false;
		}
		return true;
	}

	public boolean isUserExist(String email) {
		return userRepository.existsByEmail(email);
	}

	public boolean checkName(String name) {
		if (StringUtils.isAllBlank(name)) {
			return false;
		}
		return true;
	}

	public boolean isValidEmailAddress(String email) {
		boolean result = true;
		try {
			if (StringUtils.isAllBlank(email)) {
				return false;
			}
			InternetAddress emailAddr = new InternetAddress(email);
			emailAddr.validate();
		} catch (AddressException ex) {
			result = false;
		}
		return result;
	}

	public void readCSVFile(HttpServletResponse response, String fileName) throws IOException {

		Path filePath = Paths.get(errorFilePath + fileName).toAbsolutePath().normalize();
		try (Reader reader = Files.newBufferedReader(Paths.get(filePath.toUri()));
				CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT
						.withHeader("Email", "Name", "Roles", "Errors").withIgnoreHeaderCase().withTrim());) {
			response.setContentType("text/csv");
			response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"");
			@SuppressWarnings("resource")
			CSVPrinter csvPrinter = new CSVPrinter(response.getWriter(),
					CSVFormat.DEFAULT.withHeader("Email", "Name", "Roles", "Errors"));
			boolean start = true;
			for (CSVRecord csvRecord : csvParser) {
				if (!start)
					csvPrinter.printRecord(Arrays.asList(csvRecord.get("Email"), csvRecord.get("Name"),
							csvRecord.get("Roles"), csvRecord.get("Errors")));
				start = false;
			}
		}
	}
}
