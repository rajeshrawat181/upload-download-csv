package com.assignment.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Paths;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.assignment.DTO.ResponseDTO;
import com.assignment.helper.CSVHelper;
import com.assignment.service.CSVService;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class CSVController {

	@Autowired
	CSVService fileService;

	@PostMapping("/register")
	public ResponseEntity<ResponseDTO> uploadFile(@RequestParam("file") MultipartFile file) {
		if (CSVHelper.hasCSVFormat(file)) {
			try {
				return ResponseEntity.status(HttpStatus.OK).body(fileService.save(file));
			} catch (Exception e) {
				log.error("Error while uploading CSV file :", e);
				return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(
						ResponseDTO.builder().no_of_rows_parsed(0).no_of_rows_failed(0).error_file_url("").build());
			}
		}
		log.error("Invalid CSV file.");
		return ResponseEntity.status(HttpStatus.BAD_REQUEST)
				.body(ResponseDTO.builder().no_of_rows_parsed(0).no_of_rows_failed(0).error_file_url("").build());
	}


	  @GetMapping("/download/{file}")
	  public void downloadUsersCSV(HttpServletResponse httpServletResponse,@PathVariable("file") String fileName){
		  try {
			fileService.readCSVFile(httpServletResponse,fileName);
		} catch (IOException e) {
			log.error("Error while downloading csv error file :",e);
		}
	  }

}
