package com.assignment.helper;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;
import org.springframework.web.multipart.MultipartFile;

import com.assignment.model.Role;
import com.assignment.model.User;

public class CSVHelper {
	public static String TYPE = "text/csv";
	static String[] HEADERs = { "Id", "Title", "Description", "Published" };

	public static boolean hasCSVFormat(MultipartFile file) {
		if (!TYPE.equals(file.getContentType())) {
			return false;
		}
		return true;
	}

	public static List<User> csvToUser(InputStream is) {
		try (BufferedReader fileReader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
				CSVParser csvParser = new CSVParser(fileReader,
						CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreHeaderCase().withTrim());) {

			List<User> users = new ArrayList<User>();
			Iterable<CSVRecord> csvRecords = csvParser.getRecords();
			for (CSVRecord csvRecord : csvRecords) {
				User user = new User();
				user.setEmail(csvRecord.get("Email"));
				user.setName(csvRecord.get("Name"));
				Set<Role> roles = new HashSet<Role>();
				Role role_obj = new Role();
				role_obj.setName(csvRecord.get("Roles"));
				roles.add(role_obj);
				user.setRoles(roles);
				users.add(user);
			}
			return users;
		} catch (IOException e) {
			throw new RuntimeException("fail to parse CSV file: " + e.getMessage());
		}
	}

	public static void writeCSV(List<Map<String, Object>> invalidUsers, String fileName, String path)
			throws IOException {
		String SAMPLE_CSV_FILE = path + "errors_" + fileName;
		try (BufferedWriter writer = Files.newBufferedWriter(Paths.get(SAMPLE_CSV_FILE));
				CSVPrinter csvPrinter = new CSVPrinter(writer,
						CSVFormat.DEFAULT.withHeader("Email", "Name", "Roles", "Errors"));) {
			for (Map<String, Object> record : invalidUsers) {
				User user = (User) record.get("user");
				final Role role = new Role();
				user.getRoles().forEach(r -> role.setName(r.getName()));
				csvPrinter.printRecord(user.getEmail(), user.getName(), role.getName(), record.get("message"));
			}
			csvPrinter.flush();
		}
	}
}
